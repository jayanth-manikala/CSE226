package com.example.reminderapp



import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(private val tasks: List<TaskEntity>, private val context: Context) :
    RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view: View = LayoutInflater.from(context).inflate(R.layout.task_item, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.taskTitle.text = task.title

        val colorRes: Int
        when (task.priority) {
            "High" -> colorRes = R.color.highPriority
            "Medium" -> colorRes = R.color.mediumPriority
            "Low" -> colorRes = R.color.lowPriority
            else -> colorRes = R.color.lowPriority
        }

        holder.cardView.setCardBackgroundColor(ContextCompat.getColor(context, colorRes))

        // Set the scheduled date and time
        val dateTime = task.dateTime
        val dateText = android.text.format.DateFormat.format("yyyy-MM-dd HH:mm", dateTime)
        holder.taskDateTime.text = "Scheduled: $dateText"
    }

    override fun getItemCount(): Int {
        return tasks.size
    }

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var taskTitle: TextView = itemView.findViewById(R.id.taskTitle)
        var taskDateTime: TextView = itemView.findViewById(R.id.taskDateTime)
        var cardView: CardView = itemView as CardView
    }
}
