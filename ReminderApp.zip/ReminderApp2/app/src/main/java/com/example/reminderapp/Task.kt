package com.example.reminderapp



class Task(
    val title: String, // "High", "Medium", "Low"
    val priority: String,
    val dueTime: Int
)
