package com.example.reminderapp



import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Check notification permission
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Log or handle the case where the user has denied permission
            return
        }

        val taskTitle = intent.getStringExtra("task_title") ?: "No Title"
        val taskPriority = intent.getStringExtra("task_priority") ?: "No Priority"

        val notification = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_ID)
            .setContentTitle("Task Reminder")
            .setContentText("$taskTitle (Priority: $taskPriority)")
            .setSmallIcon(android.R.drawable.ic_notification_clear_all)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), notification)
    }
}
