package com.example.reminderapp



import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : AppCompatActivity() {

    private val taskList: MutableList<TaskEntity> = ArrayList()
    private var taskAdapter: TaskAdapter? = null
    private lateinit var taskDatabase: TaskDatabase
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        taskDatabase = TaskDatabase.getDatabase(this)
        val taskRecyclerView = findViewById<RecyclerView>(R.id.taskRecyclerView)
        val addTaskFab = findViewById<FloatingActionButton>(R.id.addTaskFab)

        taskAdapter = TaskAdapter(taskList, this)
        taskRecyclerView.layoutManager = LinearLayoutManager(this)
        taskRecyclerView.adapter = taskAdapter

        checkNotificationPermission()

        addTaskFab.setOnClickListener { showAddTaskDialog() }

        lifecycleScope.launch {
            taskList.addAll(taskDatabase.taskDao().getAllTasks())
            taskAdapter?.notifyDataSetChanged()
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun showAddTaskDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add Task")

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val titleInput = EditText(this)
        titleInput.hint = "Task Title"
        layout.addView(titleInput)

        val prioritySpinner = Spinner(this)
        val priorityAdapter = ArrayAdapter.createFromResource(
            this, R.array.priority_levels, android.R.layout.simple_spinner_item
        )
        priorityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        prioritySpinner.adapter = priorityAdapter
        layout.addView(prioritySpinner)

        builder.setView(layout)

        builder.setPositiveButton("Add") { _, _ ->
            val title = titleInput.text.toString()
            val priority = prioritySpinner.selectedItem.toString()

            if (title.isNotBlank()) {
                val calendar = Calendar.getInstance()
                DatePickerDialog(
                    this,
                    { _, year, month, day ->
                        calendar.set(year, month, day)
                        TimePickerDialog(
                            this,
                            { _, hour, minute ->
                                calendar.set(Calendar.HOUR_OF_DAY, hour)
                                calendar.set(Calendar.MINUTE, minute)

                                val newTask = TaskEntity(
                                    title = title,
                                    priority = priority,
                                    dateTime = calendar.timeInMillis
                                )

                                lifecycleScope.launch {
                                    taskDatabase.taskDao().insert(newTask)
                                    taskList.add(newTask)
                                    taskAdapter?.notifyDataSetChanged()
                                    NotificationHelper.scheduleNotification(this@MainActivity, newTask)
                                }
                            },
                            calendar.get(Calendar.HOUR_OF_DAY),
                            calendar.get(Calendar.MINUTE),
                            true
                        ).show()
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                ).show()
            } else {
                Toast.makeText(this, "Task title cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
