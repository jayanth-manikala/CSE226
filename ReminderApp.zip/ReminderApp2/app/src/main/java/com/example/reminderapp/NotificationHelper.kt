package com.example.reminderapp



import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat

class NotificationHelper {

    companion object {
        const val CHANNEL_ID = "task_channel"

        fun scheduleNotification(context: Context, task: TaskEntity) {
            // Create Notification Channel for Android O+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val notificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Task Notifications",
                    NotificationManager.IMPORTANCE_HIGH
                )
                notificationManager.createNotificationChannel(channel)
            }

            // Check if the app can schedule exact alarms
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                // Prompt user to grant permission
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                context.startActivity(intent)
                return
            }

            // Prepare the notification intent
            val intent = Intent(context, NotificationReceiver::class.java).apply {
                putExtra("task_title", task.title)
                putExtra("task_priority", task.priority)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context, task.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Schedule the exact alarm
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                task.dateTime,
                pendingIntent
            )
        }
    }
}
